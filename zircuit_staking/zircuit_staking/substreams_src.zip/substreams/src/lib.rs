mod abi;
mod pb;
use hex_literal::hex;
use pb::contract::v1 as contract;
use substreams::Hex;use substreams_entity_change::pb::entity::EntityChanges;
use substreams_entity_change::tables::Tables as EntityChangesTables;
use substreams_ethereum::pb::eth::v2 as eth;
use substreams_ethereum::Event;

#[allow(unused_imports)]
use num_traits::cast::ToPrimitive;
use std::str::FromStr;
use substreams::scalar::BigDecimal;

substreams_ethereum::init!();

const ZTAKINGPOOL_TRACKED_CONTRACT: [u8; 20] = hex!("f047ab4c75cebf0eb9ed34ae2c186f3611aeafa6");

fn map_ztakingpool_events(blk: &eth::Block, events: &mut contract::Events) {
    events.ztakingpool_blocklist_changeds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::BlocklistChanged::match_and_decode(log) {
                        return Some(contract::ZtakingpoolBlocklistChanged {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            blocked: event.blocked,
                            migrator: event.migrator,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_deposits.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::Deposit::match_and_decode(log) {
                        return Some(contract::ZtakingpoolDeposit {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            amount: event.amount.to_string(),
                            depositor: event.depositor,
                            event_id: event.event_id.to_string(),
                            token: event.token,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_eip712_domain_changeds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::Eip712DomainChanged::match_and_decode(log) {
                        return Some(contract::ZtakingpoolEip712DomainChanged {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_migrates.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::Migrate::match_and_decode(log) {
                        return Some(contract::ZtakingpoolMigrate {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            amounts: event.amounts.into_iter().map(|x| x.to_string()).collect::<Vec<_>>(),
                            destination: event.destination,
                            event_id: event.event_id.to_string(),
                            migrator: event.migrator,
                            tokens: event.tokens.into_iter().map(|x| x).collect::<Vec<_>>(),
                            user: event.user,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_ownership_transfer_starteds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::OwnershipTransferStarted::match_and_decode(log) {
                        return Some(contract::ZtakingpoolOwnershipTransferStarted {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            new_owner: event.new_owner,
                            previous_owner: event.previous_owner,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_ownership_transferreds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::OwnershipTransferred::match_and_decode(log) {
                        return Some(contract::ZtakingpoolOwnershipTransferred {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            new_owner: event.new_owner,
                            previous_owner: event.previous_owner,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_pauseds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::Paused::match_and_decode(log) {
                        return Some(contract::ZtakingpoolPaused {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            account: event.account,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_signer_changeds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::SignerChanged::match_and_decode(log) {
                        return Some(contract::ZtakingpoolSignerChanged {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            new_signer: event.new_signer,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_token_stakability_changeds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::TokenStakabilityChanged::match_and_decode(log) {
                        return Some(contract::ZtakingpoolTokenStakabilityChanged {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            enabled: event.enabled,
                            token: event.token,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_unpauseds.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::Unpaused::match_and_decode(log) {
                        return Some(contract::ZtakingpoolUnpaused {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            account: event.account,
                        });
                    }

                    None
                })
        })
        .collect());
    events.ztakingpool_withdraws.append(&mut blk
        .receipts()
        .flat_map(|view| {
            view.receipt.logs.iter()
                .filter(|log| log.address == ZTAKINGPOOL_TRACKED_CONTRACT)
                .filter_map(|log| {
                    if let Some(event) = abi::ztakingpool_contract::events::Withdraw::match_and_decode(log) {
                        return Some(contract::ZtakingpoolWithdraw {
                            evt_tx_hash: Hex(&view.transaction.hash).to_string(),
                            evt_index: log.block_index,
                            evt_block_time: Some(blk.timestamp().to_owned()),
                            evt_block_number: blk.number,
                            amount: event.amount.to_string(),
                            event_id: event.event_id.to_string(),
                            token: event.token,
                            withdrawer: event.withdrawer,
                        });
                    }

                    None
                })
        })
        .collect());
}

fn graph_ztakingpool_out(events: &contract::Events, tables: &mut EntityChangesTables) {
    // Loop over all the abis events to create table changes
    events.ztakingpool_blocklist_changeds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_blocklist_changed", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("blocked", evt.blocked)
            .set("migrator", Hex(&evt.migrator).to_string());
    });
    events.ztakingpool_deposits.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_deposit", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("amount", BigDecimal::from_str(&evt.amount).unwrap())
            .set("depositor", Hex(&evt.depositor).to_string())
            .set("event_id", BigDecimal::from_str(&evt.event_id).unwrap())
            .set("token", Hex(&evt.token).to_string());
    });
    events.ztakingpool_eip712_domain_changeds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_eip712_domain_changed", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number);
    });
    events.ztakingpool_migrates.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_migrate", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("amounts", evt.amounts.iter().map(|x| BigDecimal::from_str(&x).unwrap()).collect::<Vec<_>>())
            .set("destination", Hex(&evt.destination).to_string())
            .set("event_id", BigDecimal::from_str(&evt.event_id).unwrap())
            .set("migrator", Hex(&evt.migrator).to_string())
            .set("tokens", evt.tokens.iter().map(|x| Hex(&x).to_string()).collect::<Vec<_>>())
            .set("user", Hex(&evt.user).to_string());
    });
    events.ztakingpool_ownership_transfer_starteds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_ownership_transfer_started", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("new_owner", Hex(&evt.new_owner).to_string())
            .set("previous_owner", Hex(&evt.previous_owner).to_string());
    });
    events.ztakingpool_ownership_transferreds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_ownership_transferred", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("new_owner", Hex(&evt.new_owner).to_string())
            .set("previous_owner", Hex(&evt.previous_owner).to_string());
    });
    events.ztakingpool_pauseds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_paused", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("account", Hex(&evt.account).to_string());
    });
    events.ztakingpool_signer_changeds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_signer_changed", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("new_signer", Hex(&evt.new_signer).to_string());
    });
    events.ztakingpool_token_stakability_changeds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_token_stakability_changed", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("enabled", evt.enabled)
            .set("token", Hex(&evt.token).to_string());
    });
    events.ztakingpool_unpauseds.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_unpaused", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("account", Hex(&evt.account).to_string());
    });
    events.ztakingpool_withdraws.iter().for_each(|evt| {
        tables
            .create_row("ztakingpool_withdraw", format!("{}-{}", evt.evt_tx_hash, evt.evt_index))
            .set("evt_tx_hash", &evt.evt_tx_hash)
            .set("evt_index", evt.evt_index)
            .set("evt_block_time", evt.evt_block_time.as_ref().unwrap())
            .set("evt_block_number", evt.evt_block_number)
            .set("amount", BigDecimal::from_str(&evt.amount).unwrap())
            .set("event_id", BigDecimal::from_str(&evt.event_id).unwrap())
            .set("token", Hex(&evt.token).to_string())
            .set("withdrawer", Hex(&evt.withdrawer).to_string());
    });
}
#[substreams::handlers::map]
fn map_events(blk: eth::Block) -> Result<contract::Events, substreams::errors::Error> {
    let mut events = contract::Events::default();
    map_ztakingpool_events(&blk, &mut events);
    substreams::skip_empty_output();
    Ok(events)
}
#[substreams::handlers::map]
fn graph_out(events: contract::Events) -> Result<EntityChanges, substreams::errors::Error> {
    // Initialize Database Changes container
    let mut tables = EntityChangesTables::new();
    graph_ztakingpool_out(&events, &mut tables);
    Ok(tables.to_entity_changes())
}

